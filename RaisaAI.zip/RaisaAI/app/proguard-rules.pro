# Raisa AI — ProGuard / R8 rules.
# Release minification is disabled in Step 01, so no custom rules are required yet.
