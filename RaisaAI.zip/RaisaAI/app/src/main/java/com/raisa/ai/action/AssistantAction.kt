package com.raisa.ai.action

sealed interface AssistantAction {
    data class OpenScreen(val route: String) : AssistantAction
}

sealed interface ActionResult {
    data object Success : ActionResult
    data class Unsupported(val reason: String) : ActionResult
}

interface ActionHandler {
    fun handle(action: AssistantAction): ActionResult
}

/** Step 01 placeholder: device/app actions arrive in a later step. */
class PlaceholderActionHandler : ActionHandler {
    override fun handle(action: AssistantAction): ActionResult =
        ActionResult.Unsupported("Actions are not implemented yet")
}
