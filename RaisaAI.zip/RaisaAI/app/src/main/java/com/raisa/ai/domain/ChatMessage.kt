package com.raisa.ai.domain

enum class Sender { User, Assistant }

data class ChatMessage(
    val id: Long,
    val text: String,
    val sender: Sender,
    val timestampMillis: Long
)
