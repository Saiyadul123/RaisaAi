package com.raisa.ai.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Translate
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.raisa.ai.R
import com.raisa.ai.ui.components.QuickActionCard
import com.raisa.ai.ui.components.ScreenHeader

private class ToolItem(@StringRes val label: Int, val icon: ImageVector)

private val tools = listOf(
    ToolItem(R.string.tool_coding, Icons.Filled.Code),
    ToolItem(R.string.tool_voice, Icons.Filled.Mic),
    ToolItem(R.string.tool_translate, Icons.Filled.Translate),
    ToolItem(R.string.tool_notes, Icons.Filled.Description),
    ToolItem(R.string.tool_device, Icons.Filled.PhoneAndroid),
    ToolItem(R.string.tool_ideas, Icons.Filled.AutoAwesome)
)

@Composable
fun ToolsScreen(
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val soonMessage = stringResource(R.string.feature_coming_soon)

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 150.dp),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            ScreenHeader(
                title = stringResource(R.string.tools_title),
                subtitle = stringResource(R.string.tools_subtitle)
            )
        }
        items(items = tools) { tool ->
            QuickActionCard(
                label = stringResource(tool.label),
                icon = tool.icon,
                onClick = { onShowMessage(soonMessage) }
            )
        }
    }
}
