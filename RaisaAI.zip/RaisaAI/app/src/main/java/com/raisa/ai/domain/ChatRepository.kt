package com.raisa.ai.domain

import kotlinx.coroutines.flow.StateFlow

interface ChatRepository {
    val messages: StateFlow<List<ChatMessage>>
    fun addMessage(text: String, sender: Sender): ChatMessage
    fun clear()
}
