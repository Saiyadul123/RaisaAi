package com.raisa.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.raisa.ai.ui.theme.RaisaBgDeep
import com.raisa.ai.ui.theme.RaisaBgGlow
import com.raisa.ai.ui.theme.RaisaBlue
import com.raisa.ai.ui.theme.RaisaPink
import com.raisa.ai.ui.theme.RaisaViolet

/** Full-screen night gradient with soft violet / pink / blue glows. */
@Composable
fun RaisaBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(RaisaBgDeep, RaisaBgGlow, RaisaBgDeep)))
            .drawBehind {
                val radius = this.size.minDimension
                val violetCenter = Offset(this.size.width * 0.12f, this.size.height * 0.06f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(RaisaViolet.copy(alpha = 0.30f), Color.Transparent),
                        center = violetCenter,
                        radius = radius
                    ),
                    radius = radius,
                    center = violetCenter
                )
                val pinkCenter = Offset(this.size.width * 0.95f, this.size.height * 0.62f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(RaisaPink.copy(alpha = 0.16f), Color.Transparent),
                        center = pinkCenter,
                        radius = radius * 0.8f
                    ),
                    radius = radius * 0.8f,
                    center = pinkCenter
                )
                val blueCenter = Offset(this.size.width * 0.2f, this.size.height * 0.98f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(RaisaBlue.copy(alpha = 0.14f), Color.Transparent),
                        center = blueCenter,
                        radius = radius * 0.7f
                    ),
                    radius = radius * 0.7f,
                    center = blueCenter
                )
            },
        content = content
    )
}
