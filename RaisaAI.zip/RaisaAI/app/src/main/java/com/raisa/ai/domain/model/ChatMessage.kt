package com.raisa.ai.domain.model

enum class Sender { User, Assistant }

data class ChatMessage(
    val id: Long,
    val sender: Sender,
    val text: String,
    val timestampMillis: Long
)
