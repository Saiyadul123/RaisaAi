package com.raisa.ai.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.raisa.ai.AppContainer
import com.raisa.ai.settings.AppSettings
import com.raisa.ai.settings.SettingsRepository
import kotlinx.coroutines.flow.StateFlow

class SettingsViewModel(
    private val repository: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = repository.settings

    fun setTypingIndicatorEnabled(enabled: Boolean) {
        repository.setTypingIndicatorEnabled(enabled)
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    SettingsViewModel(container.settingsRepository) as T
            }
    }
}
