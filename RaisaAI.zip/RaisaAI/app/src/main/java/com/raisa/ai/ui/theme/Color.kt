package com.raisa.ai.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Accent palette: violet, purple, pink, blue.
val RaisaViolet = Color(0xFF8B5CF6)
val RaisaPurple = Color(0xFFA855F7)
val RaisaPink = Color(0xFFEC4899)
val RaisaBlue = Color(0xFF60A5FA)

// Night surfaces.
val RaisaBgDeep = Color(0xFF0B0716)
val RaisaBgGlow = Color(0xFF1A0F33)
val RaisaSurface = Color(0xFF140D26)
val RaisaSurfaceVariant = Color(0xFF1F1640)
val RaisaOutline = Color(0xFF3F3070)
val RaisaOutlineVariant = Color(0xFF2A2050)

// Text.
val RaisaOnBackground = Color(0xFFEDE7FF)
val RaisaOnSurfaceVariant = Color(0xFFB9ADE0)

val RaisaError = Color(0xFFFF6B8B)

val RaisaPrimaryGradient: Brush = Brush.linearGradient(listOf(RaisaViolet, RaisaPurple, RaisaPink))
