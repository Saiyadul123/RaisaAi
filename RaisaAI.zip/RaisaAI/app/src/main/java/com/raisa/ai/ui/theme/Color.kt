package com.raisa.ai.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Violet = Color(0xFF8B5CF6)
val Purple = Color(0xFFA855F7)
val Pink = Color(0xFFEC4899)
val Blue = Color(0xFF3B82F6)
val DeepViolet = Color(0xFF3B1F7A)
val DeepSpace = Color(0xFF0B0615)
val BackgroundTop = Color(0xFF1A0B33)
val SurfaceDark = Color(0xFF150D26)
val SurfaceVariantDark = Color(0xFF211538)
val OnDark = Color(0xFFF3EDFF)
val OnDarkMuted = Color(0xFFB9A9D9)
val OutlineViolet = Color(0xFF4A3A6E)
val ErrorRed = Color(0xFFFF6B8A)

val RaisaBrandBrush: Brush = Brush.linearGradient(listOf(Violet, Purple, Pink))
val RaisaBackgroundBrush: Brush = Brush.verticalGradient(listOf(BackgroundTop, DeepSpace))
