package com.raisa.ai.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.raisa.ai.ui.screens.ChatScreen
import com.raisa.ai.ui.screens.HistoryScreen
import com.raisa.ai.ui.screens.HomeScreen
import com.raisa.ai.ui.screens.SettingsScreen
import com.raisa.ai.ui.screens.SplashScreen
import com.raisa.ai.ui.screens.ToolsScreen
import com.raisa.ai.ui.viewmodel.AppViewModelProvider
import com.raisa.ai.ui.viewmodel.ChatViewModel
import com.raisa.ai.ui.viewmodel.HistoryViewModel
import com.raisa.ai.ui.viewmodel.HomeViewModel
import com.raisa.ai.ui.viewmodel.SettingsViewModel

/** Navigate to a bottom-bar destination with state saving and no duplicate entries. */
fun NavHostController.navigateTopLevel(route: String) {
    navigate(route) {
        popUpTo(Screen.Home.route) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun RaisaNavHost(
    navController: NavHostController,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route,
        modifier = modifier
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onFinished = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }
        composable(Screen.Home.route) {
            val viewModel: HomeViewModel = viewModel(factory = AppViewModelProvider.Factory)
            HomeScreen(
                viewModel = viewModel,
                onNavigate = { navController.navigateTopLevel(it.route) },
                onShowMessage = onShowMessage
            )
        }
        composable(Screen.Chat.route) {
            val viewModel: ChatViewModel = viewModel(factory = AppViewModelProvider.Factory)
            ChatScreen(viewModel = viewModel, onShowMessage = onShowMessage)
        }
        composable(Screen.Tools.route) {
            ToolsScreen(onShowMessage = onShowMessage)
        }
        composable(Screen.History.route) {
            val viewModel: HistoryViewModel = viewModel(factory = AppViewModelProvider.Factory)
            HistoryScreen(viewModel = viewModel)
        }
        composable(Screen.Settings.route) {
            val viewModel: SettingsViewModel = viewModel(factory = AppViewModelProvider.Factory)
            SettingsScreen(viewModel = viewModel)
        }
    }
}
