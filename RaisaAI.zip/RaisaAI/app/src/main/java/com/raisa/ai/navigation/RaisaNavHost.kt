package com.raisa.ai.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.raisa.ai.AppContainer
import com.raisa.ai.BuildConfig
import com.raisa.ai.R
import com.raisa.ai.action.ToolCatalog
import com.raisa.ai.domain.model.toHistoryEntries
import com.raisa.ai.ui.screens.ChatScreen
import com.raisa.ai.ui.screens.ChatViewModel
import com.raisa.ai.ui.screens.HistoryScreen
import com.raisa.ai.ui.screens.HomeScreen
import com.raisa.ai.ui.screens.SettingsScreen
import com.raisa.ai.ui.screens.SettingsViewModel
import com.raisa.ai.ui.screens.SplashScreen
import com.raisa.ai.ui.screens.ToolsScreen

@Composable
fun RaisaNavHost(
    navController: NavHostController,
    container: AppContainer,
    chatViewModel: ChatViewModel,
    settingsViewModel: SettingsViewModel,
    navigateToTab: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val chatState by chatViewModel.uiState.collectAsStateWithLifecycle()
    val settings by settingsViewModel.settings.collectAsStateWithLifecycle()
    val codingPrompt = stringResource(R.string.coding_prompt)

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route,
        modifier = modifier
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onFinished = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                voiceAvailable = container.voiceInputController.isAvailable,
                onMicClick = { container.voiceInputController.startListening() },
                onSendMessage = { text ->
                    chatViewModel.send(text)
                    navigateToTab(Screen.Chat)
                },
                onOpenChat = { navigateToTab(Screen.Chat) },
                onOpenCoding = {
                    chatViewModel.onInputChange(codingPrompt)
                    navigateToTab(Screen.Chat)
                },
                onOpenSettings = { navigateToTab(Screen.Settings) }
            )
        }

        composable(Screen.Chat.route) {
            ChatScreen(
                uiState = chatState,
                showTypingIndicator = settings.typingIndicatorEnabled,
                onInputChange = chatViewModel::onInputChange,
                onSend = chatViewModel::sendCurrentInput,
                onSuggestionClick = chatViewModel::send
            )
        }

        composable(Screen.Tools.route) {
            ToolsScreen(
                tools = ToolCatalog.tools,
                onToolClick = { tool -> container.actionExecutor.execute(tool) }
            )
        }

        composable(Screen.History.route) {
            val entries = remember(chatState.messages) { chatState.messages.toHistoryEntries() }
            HistoryScreen(
                entries = entries,
                onOpenChat = { navigateToTab(Screen.Chat) },
                onClearHistory = chatViewModel::clearConversation
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                settings = settings,
                versionName = BuildConfig.VERSION_NAME,
                onTypingIndicatorChange = settingsViewModel::setTypingIndicatorEnabled,
                onClearHistory = chatViewModel::clearConversation
            )
        }
    }
}
