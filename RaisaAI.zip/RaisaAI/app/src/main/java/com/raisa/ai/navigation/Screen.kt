package com.raisa.ai.navigation

sealed class Screen(val route: String) {
    data object Splash : Screen("splash")
    data object Home : Screen("home")
    data object Chat : Screen("chat")
    data object Tools : Screen("tools")
    data object History : Screen("history")
    data object Settings : Screen("settings")
}
