package com.raisa.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.raisa.ai.settings.AppLanguage
import com.raisa.ai.settings.AppSettings
import com.raisa.ai.settings.SettingsRepository
import kotlinx.coroutines.flow.StateFlow

class SettingsViewModel(
    private val settingsRepository: SettingsRepository
) : ViewModel() {
    val settings: StateFlow<AppSettings> = settingsRepository.settings

    fun setReplyLanguage(language: AppLanguage) = settingsRepository.setReplyLanguage(language)
}
