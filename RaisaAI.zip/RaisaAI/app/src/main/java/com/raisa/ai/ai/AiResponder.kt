package com.raisa.ai.ai

import com.raisa.ai.domain.model.ChatMessage

/**
 * Anything that can answer a chat message. Step 02 will add a Gemini-backed
 * implementation; Step 01 only ships [LocalPlaceholderResponder].
 */
interface AiResponder {
    suspend fun respond(history: List<ChatMessage>, userText: String): String
}
