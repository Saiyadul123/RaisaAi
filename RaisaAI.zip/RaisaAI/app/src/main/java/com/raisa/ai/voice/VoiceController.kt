package com.raisa.ai.voice

sealed interface VoiceResult {
    data object Started : VoiceResult
    data object Unavailable : VoiceResult
}

interface VoiceController {
    fun startListening(): VoiceResult
    fun stopListening()
}

/** Step 01 placeholder: no microphone access, no permissions requested. */
class PlaceholderVoiceController : VoiceController {
    override fun startListening(): VoiceResult = VoiceResult.Unavailable
    override fun stopListening() = Unit
}
