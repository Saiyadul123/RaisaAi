package com.raisa.ai.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.raisa.ai.R
import com.raisa.ai.ui.components.QuickActionCard
import com.raisa.ai.ui.components.RaisaAvatar
import com.raisa.ai.ui.components.RaisaBackdrop
import com.raisa.ai.ui.components.RaisaGradientButton
import com.raisa.ai.ui.components.RaisaInputBar
import com.raisa.ai.ui.theme.RaisaAITheme
import com.raisa.ai.ui.theme.RaisaBlue
import com.raisa.ai.ui.theme.RaisaPink
import com.raisa.ai.ui.theme.RaisaPurple
import com.raisa.ai.ui.theme.RaisaViolet
import java.util.Calendar
import kotlinx.coroutines.launch

@StringRes
private fun greetingResFor(hourOfDay: Int): Int = when (hourOfDay) {
    in 5..11 -> R.string.greeting_morning
    in 12..14 -> R.string.greeting_noon
    in 15..17 -> R.string.greeting_afternoon
    in 18..20 -> R.string.greeting_evening
    else -> R.string.greeting_night
}

@Composable
fun HomeScreen(
    voiceAvailable: Boolean,
    onMicClick: () -> Unit,
    onSendMessage: (String) -> Unit,
    onOpenChat: () -> Unit,
    onOpenCoding: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val voiceComingSoon = stringResource(R.string.voice_coming_soon)
    var draft by rememberSaveable { mutableStateOf("") }
    val greetingRes = remember { greetingResFor(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) }

    val showVoiceComingSoon: () -> Unit = {
        scope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(voiceComingSoon)
        }
    }
    val handleMic: () -> Unit = {
        if (voiceAvailable) onMicClick() else showVoiceComingSoon()
    }
    val handleSend: () -> Unit = {
        val text = draft.trim()
        if (text.isNotEmpty()) {
            draft = ""
            onSendMessage(text)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            BrandRow()

            RaisaAvatar(avatarSize = 168.dp)

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = stringResource(R.string.home_greeting_format, stringResource(greetingRes)),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.semantics { heading() }
                )
                Text(
                    text = stringResource(R.string.home_greeting_sub),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }

            RaisaGradientButton(
                onClick = handleMic,
                iconRes = R.drawable.ic_mic,
                label = stringResource(R.string.action_mic),
                buttonSize = 72.dp
            )

            RaisaInputBar(
                value = draft,
                onValueChange = { draft = it },
                onSend = handleSend,
                placeholder = stringResource(R.string.home_input_placeholder)
            )

            Text(
                text = stringResource(R.string.quick_actions_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { heading() }
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = stringResource(R.string.quick_chat),
                    description = stringResource(R.string.quick_chat_desc),
                    iconRes = R.drawable.ic_chat,
                    accent = RaisaViolet,
                    onClick = onOpenChat,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                )
                QuickActionCard(
                    title = stringResource(R.string.quick_voice),
                    description = stringResource(R.string.quick_voice_desc),
                    iconRes = R.drawable.ic_mic,
                    accent = RaisaPink,
                    onClick = handleMic,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = stringResource(R.string.quick_coding),
                    description = stringResource(R.string.quick_coding_desc),
                    iconRes = R.drawable.ic_code,
                    accent = RaisaBlue,
                    onClick = onOpenCoding,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                )
                QuickActionCard(
                    title = stringResource(R.string.quick_settings),
                    description = stringResource(R.string.quick_settings_desc),
                    iconRes = R.drawable.ic_settings,
                    accent = RaisaPurple,
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                )
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}

@Composable
private fun BrandRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Image(
            painter = painterResource(R.drawable.raisa_logo),
            contentDescription = stringResource(R.string.content_description_logo),
            modifier = Modifier.size(56.dp)
        )
        Column {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = stringResource(R.string.splash_tagline),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Preview(showBackground = true, widthDp = 360, heightDp = 800)
@Composable
private fun HomeScreenPreview() {
    RaisaAITheme {
        RaisaBackdrop {
            HomeScreen(
                voiceAvailable = false,
                onMicClick = {},
                onSendMessage = {},
                onOpenChat = {},
                onOpenCoding = {},
                onOpenSettings = {}
            )
        }
    }
}
