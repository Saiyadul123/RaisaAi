package com.raisa.ai.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raisa.ai.R
import com.raisa.ai.navigation.Screen
import com.raisa.ai.ui.components.ChatInputBar
import com.raisa.ai.ui.components.QuickActionCard
import com.raisa.ai.ui.components.RaisaAvatar
import com.raisa.ai.ui.theme.RaisaBrandBrush
import com.raisa.ai.ui.viewmodel.HomeViewModel
import com.raisa.ai.voice.VoiceResult

private class QuickAction(
    @StringRes val label: Int,
    val icon: ImageVector,
    val onClick: () -> Unit
)

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigate: (Screen) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isResponding by viewModel.isResponding.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    val voiceMessage = stringResource(R.string.voice_coming_soon)
    val soonMessage = stringResource(R.string.feature_coming_soon)

    val actions = listOf(
        QuickAction(R.string.action_chat, Icons.Filled.ChatBubble) { onNavigate(Screen.Chat) },
        QuickAction(R.string.action_voice, Icons.Filled.Mic) { onShowMessage(voiceMessage) },
        QuickAction(R.string.action_coding, Icons.Filled.Code) { onShowMessage(soonMessage) },
        QuickAction(R.string.action_settings, Icons.Filled.Settings) { onNavigate(Screen.Settings) }
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .imePadding(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.displaySmall.copy(
                    brush = RaisaBrandBrush,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.semantics { heading() }
            )

            RaisaAvatar(
                size = 150.dp,
                description = stringResource(R.string.home_avatar_description)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Text(
                    text = stringResource(R.string.home_greeting),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                )
            }

            ChatInputBar(
                value = input,
                onValueChange = { input = it },
                sendEnabled = input.isNotBlank() && !isResponding,
                onSend = {
                    val text = input.trim()
                    if (text.isNotEmpty()) {
                        viewModel.send(text)
                        input = ""
                        onNavigate(Screen.Chat)
                    }
                },
                onMicClick = {
                    when (viewModel.onMicClick()) {
                        VoiceResult.Unavailable -> onShowMessage(voiceMessage)
                        VoiceResult.Started -> Unit
                    }
                }
            )

            Text(
                text = stringResource(R.string.home_quick_actions_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { heading() }
            )

            actions.chunked(2).forEach { rowActions ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowActions.forEach { action ->
                        QuickActionCard(
                            label = stringResource(action.label),
                            icon = action.icon,
                            onClick = action.onClick,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
