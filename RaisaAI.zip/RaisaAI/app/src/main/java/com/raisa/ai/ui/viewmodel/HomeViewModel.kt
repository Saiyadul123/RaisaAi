package com.raisa.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raisa.ai.domain.SendMessageUseCase
import com.raisa.ai.voice.VoiceController
import com.raisa.ai.voice.VoiceResult
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class HomeViewModel(
    private val sendMessage: SendMessageUseCase,
    private val voiceController: VoiceController
) : ViewModel() {

    val isResponding: StateFlow<Boolean> = sendMessage.isResponding

    fun send(text: String) {
        viewModelScope.launch { sendMessage(text) }
    }

    fun onMicClick(): VoiceResult = voiceController.startListening()
}
