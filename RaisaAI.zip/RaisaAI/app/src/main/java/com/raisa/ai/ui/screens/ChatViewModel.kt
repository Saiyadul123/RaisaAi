package com.raisa.ai.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.raisa.ai.AppContainer
import com.raisa.ai.ai.AiResponder
import com.raisa.ai.domain.model.ChatMessage
import com.raisa.ai.domain.model.Sender
import com.raisa.ai.domain.repository.ChatRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val isAssistantReplying: Boolean = false
) {
    val canSend: Boolean get() = input.isNotBlank() && !isAssistantReplying
}

class ChatViewModel(
    private val repository: ChatRepository,
    private val responder: AiResponder
) : ViewModel() {

    private val input = MutableStateFlow("")
    private val replying = MutableStateFlow(false)
    private var replyJob: Job? = null

    val uiState: StateFlow<ChatUiState> = combine(
        repository.messages,
        input,
        replying
    ) { messages, currentInput, isReplying ->
        ChatUiState(
            messages = messages,
            input = currentInput,
            isAssistantReplying = isReplying
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = ChatUiState()
    )

    fun onInputChange(value: String) {
        input.value = value
    }

    fun sendCurrentInput() {
        send(input.value)
    }

    fun send(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || replying.value) return

        input.value = ""
        repository.addMessage(Sender.User, trimmed)

        replying.value = true
        replyJob = viewModelScope.launch {
            try {
                val reply = responder.respond(repository.messages.value, trimmed)
                repository.addMessage(Sender.Assistant, reply)
            } finally {
                replying.value = false
            }
        }
    }

    fun clearConversation() {
        replyJob?.cancel()
        replyJob = null
        replying.value = false
        repository.clear()
    }

    companion object {
        private const val STOP_TIMEOUT_MILLIS = 5_000L

        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    ChatViewModel(container.chatRepository, container.aiResponder) as T
            }
    }
}
