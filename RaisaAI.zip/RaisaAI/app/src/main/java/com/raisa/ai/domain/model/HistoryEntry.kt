package com.raisa.ai.domain.model

/** One question the user asked, together with Raisa's reply (if one has arrived yet). */
data class HistoryEntry(
    val prompt: ChatMessage,
    val reply: ChatMessage?
)

/** Groups a flat message list into question/answer pairs, newest first. */
fun List<ChatMessage>.toHistoryEntries(): List<HistoryEntry> {
    val entries = mutableListOf<HistoryEntry>()
    var index = 0
    while (index < size) {
        val current = this[index]
        if (current.sender == Sender.User) {
            val next = getOrNull(index + 1)
            val reply = if (next != null && next.sender == Sender.Assistant) next else null
            entries.add(HistoryEntry(prompt = current, reply = reply))
            index += if (reply != null) 2 else 1
        } else {
            index += 1
        }
    }
    return entries.reversed()
}
