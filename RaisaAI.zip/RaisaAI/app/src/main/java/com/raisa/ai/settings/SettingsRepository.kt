package com.raisa.ai.settings

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class AppSettings(
    val typingIndicatorEnabled: Boolean = true
)

interface SettingsRepository {
    val settings: StateFlow<AppSettings>

    fun setTypingIndicatorEnabled(enabled: Boolean)
}

/** Step 01: settings are kept in memory only. A DataStore-backed version can replace this later. */
class InMemorySettingsRepository : SettingsRepository {

    private val _settings = MutableStateFlow(AppSettings())

    override val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    override fun setTypingIndicatorEnabled(enabled: Boolean) {
        _settings.update { current -> current.copy(typingIndicatorEnabled = enabled) }
    }
}
