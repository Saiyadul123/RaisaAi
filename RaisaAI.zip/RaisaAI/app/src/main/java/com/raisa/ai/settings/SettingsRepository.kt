package com.raisa.ai.settings

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class AppSettings(
    val replyLanguage: AppLanguage = AppLanguage.Bengali
)

interface SettingsRepository {
    val settings: StateFlow<AppSettings>
    fun setReplyLanguage(language: AppLanguage)
}

/** In-memory only for Step 01. A persistent (DataStore) version can replace this later. */
class InMemorySettingsRepository : SettingsRepository {
    private val _settings = MutableStateFlow(AppSettings())
    override val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    override fun setReplyLanguage(language: AppLanguage) {
        _settings.update { it.copy(replyLanguage = language) }
    }
}
