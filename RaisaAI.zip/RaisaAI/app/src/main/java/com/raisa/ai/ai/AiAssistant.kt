package com.raisa.ai.ai

import com.raisa.ai.settings.AppLanguage

/** Abstraction for any AI backend. Step 02 will add a real implementation. */
interface AiAssistant {
    suspend fun reply(prompt: String, language: AppLanguage): String
}
