package com.raisa.ai

import android.content.Context
import com.raisa.ai.action.ActionExecutor
import com.raisa.ai.action.PlaceholderActionExecutor
import com.raisa.ai.ai.AiResponder
import com.raisa.ai.ai.LocalPlaceholderResponder
import com.raisa.ai.data.InMemoryChatRepository
import com.raisa.ai.domain.repository.ChatRepository
import com.raisa.ai.settings.InMemorySettingsRepository
import com.raisa.ai.settings.SettingsRepository
import com.raisa.ai.voice.PlaceholderVoiceInputController
import com.raisa.ai.voice.VoiceInputController

/** Tiny hand-written dependency container; swap implementations here in later steps. */
class AppContainer(context: Context) {

    private val appContext: Context = context.applicationContext

    val chatRepository: ChatRepository by lazy { InMemoryChatRepository() }
    val settingsRepository: SettingsRepository by lazy { InMemorySettingsRepository() }
    val aiResponder: AiResponder by lazy { LocalPlaceholderResponder(appContext) }
    val voiceInputController: VoiceInputController by lazy { PlaceholderVoiceInputController() }
    val actionExecutor: ActionExecutor by lazy { PlaceholderActionExecutor() }
}
