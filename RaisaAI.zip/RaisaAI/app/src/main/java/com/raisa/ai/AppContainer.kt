package com.raisa.ai

import com.raisa.ai.action.ActionHandler
import com.raisa.ai.action.PlaceholderActionHandler
import com.raisa.ai.ai.AiAssistant
import com.raisa.ai.ai.PlaceholderAssistant
import com.raisa.ai.data.InMemoryChatRepository
import com.raisa.ai.domain.ChatRepository
import com.raisa.ai.domain.SendMessageUseCase
import com.raisa.ai.settings.InMemorySettingsRepository
import com.raisa.ai.settings.SettingsRepository
import com.raisa.ai.voice.PlaceholderVoiceController
import com.raisa.ai.voice.VoiceController

/** Minimal manual dependency container. Swap for Hilt/Koin later if desired. */
object AppContainer {
    val chatRepository: ChatRepository by lazy { InMemoryChatRepository() }
    val settingsRepository: SettingsRepository by lazy { InMemorySettingsRepository() }
    val assistant: AiAssistant by lazy { PlaceholderAssistant() }
    val voiceController: VoiceController by lazy { PlaceholderVoiceController() }
    val actionHandler: ActionHandler by lazy { PlaceholderActionHandler() }
    val sendMessage: SendMessageUseCase by lazy {
        SendMessageUseCase(chatRepository, assistant, settingsRepository)
    }
}
