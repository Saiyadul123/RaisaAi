package com.raisa.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raisa.ai.R
import com.raisa.ai.ui.components.ChatInputBar
import com.raisa.ai.ui.components.EmptyState
import com.raisa.ai.ui.components.MessageBubble
import com.raisa.ai.ui.components.ScreenHeader
import com.raisa.ai.ui.viewmodel.ChatViewModel
import com.raisa.ai.voice.VoiceResult

@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val voiceMessage = stringResource(R.string.voice_coming_soon)

    val itemCount = state.messages.size + if (state.isResponding) 1 else 0
    LaunchedEffect(itemCount) {
        if (itemCount > 0) listState.animateScrollToItem(itemCount - 1)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        ScreenHeader(
            title = stringResource(R.string.chat_title),
            actions = {
                IconButton(
                    onClick = { viewModel.clear() },
                    enabled = state.messages.isNotEmpty()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = stringResource(R.string.chat_clear_description)
                    )
                }
            }
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Info,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = stringResource(R.string.chat_demo_notice),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (state.messages.isEmpty()) {
                EmptyState(
                    icon = Icons.Filled.AutoAwesome,
                    title = stringResource(R.string.chat_empty_title),
                    body = stringResource(R.string.chat_empty_body),
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(items = state.messages, key = { it.id }) { message ->
                        MessageBubble(message = message)
                    }
                    if (state.isResponding) {
                        item(key = "typing") {
                            Text(
                                text = stringResource(R.string.chat_typing),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        ChatInputBar(
            value = input,
            onValueChange = { input = it },
            sendEnabled = input.isNotBlank() && !state.isResponding,
            onSend = {
                val text = input.trim()
                if (text.isNotEmpty()) {
                    viewModel.send(text)
                    input = ""
                }
            },
            onMicClick = {
                when (viewModel.onMicClick()) {
                    VoiceResult.Unavailable -> onShowMessage(voiceMessage)
                    VoiceResult.Started -> Unit
                }
            }
        )
    }
}
