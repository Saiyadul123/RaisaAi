package com.raisa.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RaisaDarkColorScheme = darkColorScheme(
    primary = RaisaViolet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF3B2A7A),
    onPrimaryContainer = Color(0xFFE6DDFF),
    secondary = RaisaPink,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF5A1F44),
    onSecondaryContainer = Color(0xFFFFD9EA),
    tertiary = RaisaBlue,
    onTertiary = Color(0xFF06223F),
    tertiaryContainer = Color(0xFF173A63),
    onTertiaryContainer = Color(0xFFD3E6FF),
    background = RaisaBgDeep,
    onBackground = RaisaOnBackground,
    surface = RaisaSurface,
    onSurface = RaisaOnBackground,
    surfaceVariant = RaisaSurfaceVariant,
    onSurfaceVariant = RaisaOnSurfaceVariant,
    surfaceContainer = RaisaSurface,
    surfaceContainerHigh = RaisaSurfaceVariant,
    surfaceContainerHighest = RaisaSurfaceVariant,
    outline = RaisaOutline,
    outlineVariant = RaisaOutlineVariant,
    error = RaisaError,
    onError = Color(0xFF3B0016)
)

/** Raisa AI is dark-first: the futuristic dark scheme is used regardless of the system setting. */
@Composable
fun RaisaAITheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RaisaDarkColorScheme,
        typography = RaisaTypography,
        content = content
    )
}
