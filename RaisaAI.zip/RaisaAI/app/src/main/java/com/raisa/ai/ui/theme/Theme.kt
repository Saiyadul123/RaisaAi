package com.raisa.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RaisaDarkColorScheme = darkColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    primaryContainer = DeepViolet,
    onPrimaryContainer = OnDark,
    secondary = Pink,
    onSecondary = Color.White,
    tertiary = Blue,
    onTertiary = Color.White,
    background = DeepSpace,
    onBackground = OnDark,
    surface = SurfaceDark,
    onSurface = OnDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = OnDarkMuted,
    outline = OutlineViolet,
    error = ErrorRed
)

/** Raisa AI is dark-first. A light scheme can be added later. */
@Composable
fun RaisaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RaisaDarkColorScheme,
        typography = RaisaTypography,
        content = content
    )
}
