package com.raisa.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raisa.ai.domain.ChatMessage
import com.raisa.ai.domain.ChatRepository
import com.raisa.ai.domain.SendMessageUseCase
import com.raisa.ai.voice.VoiceController
import com.raisa.ai.voice.VoiceResult
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isResponding: Boolean = false
)

class ChatViewModel(
    private val chatRepository: ChatRepository,
    private val sendMessage: SendMessageUseCase,
    private val voiceController: VoiceController
) : ViewModel() {

    val uiState: StateFlow<ChatUiState> = combine(
        chatRepository.messages,
        sendMessage.isResponding
    ) { messages, responding ->
        ChatUiState(messages = messages, isResponding = responding)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ChatUiState()
    )

    fun send(text: String) {
        viewModelScope.launch { sendMessage(text) }
    }

    fun clear() = chatRepository.clear()

    fun onMicClick(): VoiceResult = voiceController.startListening()
}
