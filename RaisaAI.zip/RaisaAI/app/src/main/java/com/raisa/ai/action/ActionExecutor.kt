package com.raisa.ai.action

sealed interface ActionResult {
    data object Done : ActionResult
    data object ComingSoon : ActionResult
}

/** Runs a tool / device action on behalf of the assistant. */
interface ActionExecutor {
    fun execute(tool: AssistantTool): ActionResult
}

/** Step 01 placeholder: nothing is wired up yet, so unavailable tools report [ActionResult.ComingSoon]. */
class PlaceholderActionExecutor : ActionExecutor {
    override fun execute(tool: AssistantTool): ActionResult =
        if (tool.isAvailable) ActionResult.Done else ActionResult.ComingSoon
}
