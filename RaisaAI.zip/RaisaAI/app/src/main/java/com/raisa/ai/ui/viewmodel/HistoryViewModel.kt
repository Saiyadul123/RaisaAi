package com.raisa.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raisa.ai.domain.ChatMessage
import com.raisa.ai.domain.ChatRepository
import com.raisa.ai.domain.Sender
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class HistoryViewModel(
    private val chatRepository: ChatRepository
) : ViewModel() {

    /** The user's prompts from this session, newest first. */
    val items: StateFlow<List<ChatMessage>> = chatRepository.messages
        .map { list -> list.filter { it.sender == Sender.User }.asReversed() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    fun clear() = chatRepository.clear()
}
