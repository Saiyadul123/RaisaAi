package com.raisa.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.raisa.ai.R
import com.raisa.ai.settings.AppSettings
import com.raisa.ai.ui.components.ConfirmClearDialog
import com.raisa.ai.ui.components.ScreenHeader
import com.raisa.ai.ui.components.SettingsActionRow
import com.raisa.ai.ui.components.SettingsDivider
import com.raisa.ai.ui.components.SettingsInfoRow
import com.raisa.ai.ui.components.SettingsSection
import com.raisa.ai.ui.components.SettingsSwitchRow

@Composable
fun SettingsScreen(
    settings: AppSettings,
    versionName: String,
    onTypingIndicatorChange: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showClearDialog by rememberSaveable { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = stringResource(R.string.settings_title),
            subtitle = stringResource(R.string.settings_subtitle)
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            SettingsSection(title = stringResource(R.string.settings_section_appearance)) {
                SettingsInfoRow(
                    title = stringResource(R.string.settings_theme),
                    value = stringResource(R.string.settings_theme_value)
                )
                SettingsDivider()
                SettingsInfoRow(
                    title = stringResource(R.string.settings_language),
                    value = stringResource(R.string.settings_language_value)
                )
            }

            SettingsSection(title = stringResource(R.string.settings_section_chat)) {
                SettingsSwitchRow(
                    title = stringResource(R.string.settings_typing),
                    description = stringResource(R.string.settings_typing_desc),
                    checked = settings.typingIndicatorEnabled,
                    onCheckedChange = onTypingIndicatorChange
                )
            }

            SettingsSection(title = stringResource(R.string.settings_section_ai)) {
                SettingsInfoRow(
                    title = stringResource(R.string.settings_ai_provider),
                    value = stringResource(R.string.settings_ai_provider_value)
                )
                SettingsDivider()
                SettingsInfoRow(
                    title = stringResource(R.string.settings_voice),
                    value = stringResource(R.string.settings_voice_value)
                )
            }

            SettingsSection(title = stringResource(R.string.settings_section_data)) {
                SettingsActionRow(
                    title = stringResource(R.string.settings_clear_history),
                    description = stringResource(R.string.settings_clear_history_desc),
                    onClick = { showClearDialog = true }
                )
            }

            SettingsSection(title = stringResource(R.string.settings_section_about)) {
                SettingsInfoRow(
                    title = stringResource(R.string.settings_version),
                    value = versionName
                )
            }
        }
    }

    if (showClearDialog) {
        ConfirmClearDialog(
            onConfirm = {
                onClearHistory()
                showClearDialog = false
            },
            onDismiss = { showClearDialog = false }
        )
    }
}
