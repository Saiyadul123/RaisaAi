package com.raisa.ai.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.raisa.ai.ui.theme.RaisaOutline
import com.raisa.ai.ui.theme.RaisaPrimaryGradient

/** Round, gradient icon button (mic, send). [label] is read aloud by screen readers. */
@Composable
fun RaisaGradientButton(
    onClick: () -> Unit,
    @DrawableRes iconRes: Int,
    label: String,
    modifier: Modifier = Modifier,
    buttonSize: Dp = 56.dp,
    enabled: Boolean = true,
    brush: Brush = RaisaPrimaryGradient
) {
    val fill: Brush = if (enabled) brush else SolidColor(RaisaOutline)
    Box(
        modifier = modifier
            .size(buttonSize)
            .clip(CircleShape)
            .background(fill)
            .clickable(enabled = enabled, onClickLabel = label, role = Role.Button, onClick = onClick)
            .semantics { this.contentDescription = label },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = null,
            tint = if (enabled) Color.White else Color.White.copy(alpha = 0.55f),
            modifier = Modifier.size(buttonSize * 0.42f)
        )
    }
}
