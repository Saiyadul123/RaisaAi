package com.raisa.ai.ai

import android.content.Context
import com.raisa.ai.R
import com.raisa.ai.domain.model.ChatMessage
import kotlinx.coroutines.delay

/**
 * Local-only stand-in. It does NOT talk to any AI service; it simply tells the user
 * that the app is in demo mode and echoes what they wrote.
 */
class LocalPlaceholderResponder(private val context: Context) : AiResponder {

    override suspend fun respond(history: List<ChatMessage>, userText: String): String {
        delay(REPLY_DELAY_MILLIS)
        val preview = if (userText.length > MAX_ECHO_LENGTH) {
            userText.take(MAX_ECHO_LENGTH) + "…"
        } else {
            userText
        }
        return context.getString(R.string.local_reply_format, preview)
    }

    private companion object {
        const val REPLY_DELAY_MILLIS = 700L
        const val MAX_ECHO_LENGTH = 80
    }
}
