package com.raisa.ai.ui

import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.padding
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.raisa.ai.navigation.RaisaNavHost
import com.raisa.ai.navigation.bottomNavItems
import com.raisa.ai.navigation.navigateTopLevel
import com.raisa.ai.ui.components.RaisaBackground
import com.raisa.ai.ui.components.RaisaBottomBar
import kotlinx.coroutines.launch

@Composable
fun RaisaApp() {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = bottomNavItems.any { it.screen.route == currentRoute }

    RaisaBackground {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showBottomBar) {
                    RaisaBottomBar(
                        currentRoute = currentRoute,
                        onItemClick = { navController.navigateTopLevel(it.route) }
                    )
                }
            }
        ) { innerPadding ->
            RaisaNavHost(
                navController = navController,
                onShowMessage = { message ->
                    scope.launch {
                        snackbarHostState.currentSnackbarData?.dismiss()
                        snackbarHostState.showSnackbar(message)
                    }
                },
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}
