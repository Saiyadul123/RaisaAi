package com.raisa.ai.ui

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.raisa.ai.AppContainer
import com.raisa.ai.navigation.RaisaNavHost
import com.raisa.ai.navigation.Screen
import com.raisa.ai.navigation.bottomNavItems
import com.raisa.ai.ui.components.RaisaBackdrop
import com.raisa.ai.ui.components.RaisaBottomBar
import com.raisa.ai.ui.screens.ChatViewModel
import com.raisa.ai.ui.screens.SettingsViewModel

/** App shell: gradient backdrop, bottom navigation and the navigation graph. */
@Composable
fun RaisaApp(container: AppContainer) {
    val navController = rememberNavController()

    // Activity-scoped, so Home, Chat, History and Settings all share the same conversation state.
    val chatViewModel: ChatViewModel = viewModel(factory = ChatViewModel.factory(container))
    val settingsViewModel: SettingsViewModel = viewModel(factory = SettingsViewModel.factory(container))

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val density = LocalDensity.current
    val imeVisible by remember { derivedStateOf { WindowInsets.ime.getBottom(density) > 0 } }
    val showBottomBar = bottomNavItems.any { it.screen.route == currentRoute } && !imeVisible

    val navigateToTab: (Screen) -> Unit = { screen ->
        navController.navigate(screen.route) {
            popUpTo(Screen.Home.route) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    RaisaBackdrop {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            bottomBar = {
                if (showBottomBar) {
                    RaisaBottomBar(
                        items = bottomNavItems,
                        selectedRoute = currentRoute,
                        onItemClick = { item -> navigateToTab(item.screen) }
                    )
                }
            }
        ) { innerPadding ->
            RaisaNavHost(
                navController = navController,
                container = container,
                chatViewModel = chatViewModel,
                settingsViewModel = settingsViewModel,
                navigateToTab = navigateToTab,
                modifier = Modifier
                    .padding(innerPadding)
                    .consumeWindowInsets(innerPadding)
            )
        }
    }
}
