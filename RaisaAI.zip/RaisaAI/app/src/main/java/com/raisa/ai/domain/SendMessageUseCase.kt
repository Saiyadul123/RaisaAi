package com.raisa.ai.domain

import com.raisa.ai.ai.AiAssistant
import com.raisa.ai.settings.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Stores the user's message, asks the assistant for a reply, and stores the reply. */
class SendMessageUseCase(
    private val chatRepository: ChatRepository,
    private val assistant: AiAssistant,
    private val settingsRepository: SettingsRepository
) {
    private val _isResponding = MutableStateFlow(false)
    val isResponding: StateFlow<Boolean> = _isResponding.asStateFlow()

    suspend operator fun invoke(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty()) return
        chatRepository.addMessage(text, Sender.User)
        _isResponding.value = true
        try {
            val language = settingsRepository.settings.value.replyLanguage
            val reply = assistant.reply(text, language)
            chatRepository.addMessage(reply, Sender.Assistant)
        } finally {
            _isResponding.value = false
        }
    }
}
