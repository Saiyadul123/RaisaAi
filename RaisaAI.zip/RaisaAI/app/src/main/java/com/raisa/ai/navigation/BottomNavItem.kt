package com.raisa.ai.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector
import com.raisa.ai.R

data class BottomNavItem(
    val screen: Screen,
    @StringRes val labelRes: Int,
    val icon: ImageVector
)

val bottomNavItems: List<BottomNavItem> = listOf(
    BottomNavItem(Screen.Home, R.string.nav_home, Icons.Filled.Home),
    BottomNavItem(Screen.Chat, R.string.nav_chat, Icons.Filled.ChatBubble),
    BottomNavItem(Screen.Tools, R.string.nav_tools, Icons.Filled.Build),
    BottomNavItem(Screen.History, R.string.nav_history, Icons.Filled.History),
    BottomNavItem(Screen.Settings, R.string.nav_settings, Icons.Filled.Settings)
)
