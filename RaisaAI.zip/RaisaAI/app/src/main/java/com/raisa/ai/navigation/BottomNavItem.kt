package com.raisa.ai.navigation

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.raisa.ai.R

data class BottomNavItem(
    val screen: Screen,
    @StringRes val labelRes: Int,
    @DrawableRes val iconRes: Int
)

/** Destinations shown in the bottom bar, in display order. */
val bottomNavItems: List<BottomNavItem> = listOf(
    BottomNavItem(Screen.Home, R.string.nav_home, R.drawable.ic_home),
    BottomNavItem(Screen.Chat, R.string.nav_chat, R.drawable.ic_chat),
    BottomNavItem(Screen.Tools, R.string.nav_tools, R.drawable.ic_tools),
    BottomNavItem(Screen.History, R.string.nav_history, R.drawable.ic_history),
    BottomNavItem(Screen.Settings, R.string.nav_settings, R.drawable.ic_settings)
)
