package com.raisa.ai.action

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.raisa.ai.R

data class AssistantTool(
    val id: String,
    @StringRes val titleRes: Int,
    @StringRes val descriptionRes: Int,
    @DrawableRes val iconRes: Int,
    val isAvailable: Boolean
)

/** The list shown on the Tools screen. Every entry is a "coming soon" placeholder in Step 01. */
object ToolCatalog {
    val tools: List<AssistantTool> = listOf(
        AssistantTool("translate", R.string.tool_translate, R.string.tool_translate_desc, R.drawable.ic_swap, false),
        AssistantTool("summarize", R.string.tool_summarize, R.string.tool_summarize_desc, R.drawable.ic_notes, false),
        AssistantTool("code", R.string.tool_code, R.string.tool_code_desc, R.drawable.ic_code, false),
        AssistantTool("voice_notes", R.string.tool_voice_notes, R.string.tool_voice_notes_desc, R.drawable.ic_mic, false),
        AssistantTool("reminders", R.string.tool_reminders, R.string.tool_reminders_desc, R.drawable.ic_bell, false),
        AssistantTool("ideas", R.string.tool_ideas, R.string.tool_ideas_desc, R.drawable.ic_idea, false)
    )
}
