package com.raisa.ai.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class VoiceState { Idle, Listening, Unavailable }

/** Contract for speech input. A real implementation (and the mic permission) arrives in a later step. */
interface VoiceInputController {
    val isAvailable: Boolean
    val state: StateFlow<VoiceState>

    fun startListening()

    fun stopListening()
}

/** Step 01 placeholder: voice is not available yet, so every call is a no-op. */
class PlaceholderVoiceInputController : VoiceInputController {

    private val _state = MutableStateFlow(VoiceState.Unavailable)

    override val isAvailable: Boolean = false
    override val state: StateFlow<VoiceState> = _state.asStateFlow()

    override fun startListening() = Unit

    override fun stopListening() = Unit
}
