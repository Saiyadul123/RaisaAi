package com.raisa.ai.ai

import com.raisa.ai.settings.AppLanguage
import kotlinx.coroutines.delay

/** Offline stand-in. It does NOT use any AI model; it only acknowledges the message. */
class PlaceholderAssistant : AiAssistant {
    override suspend fun reply(prompt: String, language: AppLanguage): String {
        delay(700)
        val preview = prompt.take(80)
        return when (language) {
            AppLanguage.Bengali ->
                "[ডেমো] এখনো কোনো এআই মডেল সংযুক্ত নেই। তুমি লিখেছ: “${preview}”"
            AppLanguage.English ->
                "[Demo] No AI model is connected yet. You wrote: “${preview}”"
        }
    }
}
