package com.raisa.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.raisa.ai.R
import com.raisa.ai.ui.theme.RaisaBlue
import com.raisa.ai.ui.theme.RaisaPink
import com.raisa.ai.ui.theme.RaisaPurple
import com.raisa.ai.ui.theme.RaisaSurface
import com.raisa.ai.ui.theme.RaisaViolet

enum class AvatarState { Idle, Listening, Speaking }

/**
 * Placeholder assistant avatar: the Raisa artwork inside a softly pulsing, rotating gradient ring.
 *
 * This composable is the single place the avatar is drawn. Later it can be replaced by an
 * animated character (Lottie, Rive, ...) driven by [state] without changing any screen.
 */
@Composable
fun RaisaAvatar(
    modifier: Modifier = Modifier,
    avatarSize: Dp = 180.dp,
    state: AvatarState = AvatarState.Idle
) {
    val transition = rememberInfiniteTransition(label = "avatar")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 9000, easing = LinearEasing)),
        label = "ring"
    )
    val pulseDuration = if (state == AvatarState.Idle) 2400 else 1100
    val pulse by transition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = pulseDuration, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val ringBrush = remember {
        Brush.sweepGradient(listOf(RaisaViolet, RaisaPink, RaisaBlue, RaisaPurple, RaisaViolet))
    }
    val description = stringResource(R.string.content_description_avatar)

    Box(
        modifier = modifier
            .size(avatarSize)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    val outer = this.size.minDimension / 2f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(RaisaPurple.copy(alpha = 0.55f * pulse), Color.Transparent),
                            center = this.center,
                            radius = outer
                        ),
                        radius = outer,
                        center = this.center
                    )
                    rotate(rotation) {
                        drawCircle(
                            brush = ringBrush,
                            radius = outer * 0.84f,
                            center = this.center,
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }
                }
        )
        Image(
            painter = painterResource(R.drawable.raisa_logo),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize(0.76f)
                .clip(CircleShape)
                .background(RaisaSurface)
                .graphicsLayer {
                    // Zoom in on the face / brain so the avatar does not show the wordmark.
                    scaleX = 1.9f
                    scaleY = 1.9f
                    transformOrigin = TransformOrigin(0.5f, 0.34f)
                }
        )
    }
}
