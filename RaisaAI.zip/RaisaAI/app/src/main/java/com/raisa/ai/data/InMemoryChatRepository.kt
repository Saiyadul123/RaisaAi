package com.raisa.ai.data

import com.raisa.ai.domain.ChatMessage
import com.raisa.ai.domain.ChatRepository
import com.raisa.ai.domain.Sender
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** In-memory only for Step 01. A Room-backed version can replace this later. */
class InMemoryChatRepository : ChatRepository {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    override val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    private val nextId = AtomicLong(1L)

    override fun addMessage(text: String, sender: Sender): ChatMessage {
        val message = ChatMessage(
            id = nextId.getAndIncrement(),
            text = text,
            sender = sender,
            timestampMillis = System.currentTimeMillis()
        )
        _messages.update { it + message }
        return message
    }

    override fun clear() {
        _messages.value = emptyList()
    }
}
