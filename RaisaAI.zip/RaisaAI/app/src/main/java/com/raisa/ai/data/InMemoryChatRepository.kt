package com.raisa.ai.data

import com.raisa.ai.domain.model.ChatMessage
import com.raisa.ai.domain.model.Sender
import com.raisa.ai.domain.repository.ChatRepository
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Step 01 storage: messages live in memory only and disappear when the process ends.
 * A persistent (Room / DataStore) implementation can replace this later without
 * touching the UI, because everything depends on [ChatRepository].
 */
class InMemoryChatRepository : ChatRepository {

    private val nextId = AtomicLong(0L)
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())

    override val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    override fun addMessage(sender: Sender, text: String): ChatMessage {
        val message = ChatMessage(
            id = nextId.getAndIncrement(),
            sender = sender,
            text = text,
            timestampMillis = System.currentTimeMillis()
        )
        _messages.update { current -> current + message }
        return message
    }

    override fun clear() {
        _messages.value = emptyList()
    }
}
