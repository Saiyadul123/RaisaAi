package com.raisa.ai.settings

enum class AppLanguage(val code: String) {
    Bengali("bn"),
    English("en")
}
