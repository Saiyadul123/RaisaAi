package com.raisa.ai.ui.viewmodel

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.raisa.ai.AppContainer

object AppViewModelProvider {
    val Factory: ViewModelProvider.Factory = viewModelFactory {
        initializer {
            HomeViewModel(AppContainer.sendMessage, AppContainer.voiceController)
        }
        initializer {
            ChatViewModel(
                AppContainer.chatRepository,
                AppContainer.sendMessage,
                AppContainer.voiceController
            )
        }
        initializer { HistoryViewModel(AppContainer.chatRepository) }
        initializer { SettingsViewModel(AppContainer.settingsRepository) }
    }
}
