package com.raisa.ai.domain.repository

import com.raisa.ai.domain.model.ChatMessage
import com.raisa.ai.domain.model.Sender
import kotlinx.coroutines.flow.StateFlow

interface ChatRepository {
    val messages: StateFlow<List<ChatMessage>>

    fun addMessage(sender: Sender, text: String): ChatMessage

    fun clear()
}
