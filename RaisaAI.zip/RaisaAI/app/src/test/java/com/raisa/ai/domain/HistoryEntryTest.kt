package com.raisa.ai.domain

import com.raisa.ai.domain.model.ChatMessage
import com.raisa.ai.domain.model.Sender
import com.raisa.ai.domain.model.toHistoryEntries
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HistoryEntryTest {

    private fun message(id: Long, sender: Sender, text: String) =
        ChatMessage(id = id, sender = sender, text = text, timestampMillis = id)

    @Test
    fun pairsQuestionsWithRepliesNewestFirst() {
        val messages = listOf(
            message(0, Sender.User, "one"),
            message(1, Sender.Assistant, "reply one"),
            message(2, Sender.User, "two"),
            message(3, Sender.Assistant, "reply two")
        )

        val entries = messages.toHistoryEntries()

        assertEquals(2, entries.size)
        assertEquals("two", entries[0].prompt.text)
        assertEquals("reply two", entries[0].reply?.text)
        assertEquals("one", entries[1].prompt.text)
    }

    @Test
    fun keepsUnansweredQuestionWithoutReply() {
        val entries = listOf(message(0, Sender.User, "waiting")).toHistoryEntries()

        assertEquals(1, entries.size)
        assertNull(entries[0].reply)
    }

    @Test
    fun emptyListGivesNoEntries() {
        assertEquals(0, emptyList<ChatMessage>().toHistoryEntries().size)
    }
}
