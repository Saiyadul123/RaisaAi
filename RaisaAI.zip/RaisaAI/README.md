# Raisa AI — Step 01: Android project foundation

A futuristic personal AI assistant with a warm, friendly female companion personality.
This step contains only the buildable app skeleton: no AI service, no voice, no permissions, no API keys.

## Status

- Gradle sync / `assembleDebug` has **not** been run by the author of this project skeleton
  (the environment it was generated in had no access to the Android SDK or Google Maven).
- What *was* verified: the non-UI layers (domain, data, settings, voice, ai, action, container)
  compile with Kotlin 2.0.21 and behave as expected, and the JUnit test passes.
  Resources, string parity (Bengali/English), `R.*` references and imports were statically checked.
- The Compose UI code has not been compiled. Please run the build below and report any error.

## Requirements

- Android Studio (current stable release, e.g. Ladybug or newer) with its bundled JDK 17+
- Android SDK Platform 35 (Android Studio offers to install it on first sync)
- Internet access for the first Gradle sync (downloads Gradle 8.10.2, AGP 8.7.3, Compose BOM 2024.12.01)

## Build in Android Studio

1. **File > Open**, choose the `RaisaAI` folder, and wait for **Gradle Sync** to finish.
2. If asked, install **Android SDK Platform 35** (SDK Manager > SDK Platforms).
3. Pick an emulator or a phone (Android 7.0 / API 24 or newer) in the device list.
4. Press **Run** (green triangle), or **Build > Make Project**.

## Build from a terminal

```bash
cd RaisaAI
# Android Studio normally creates local.properties for you. If you build without it:
echo "sdk.dir=$HOME/Android/Sdk" > local.properties     # macOS: $HOME/Library/Android/sdk

./gradlew assembleDebug          # Windows: gradlew.bat assembleDebug
./gradlew testDebugUnitTest      # runs the unit tests
./gradlew installDebug           # installs on a connected device / emulator
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## If the build fails

- **"SDK location not found"** — create `local.properties` as shown above.
- **"Unsupported class file major version"** — set Gradle JDK to 17 or 21 in
  *Settings > Build, Execution, Deployment > Build Tools > Gradle*.
- **Version warnings** — the versions in `gradle/libs.versions.toml` are known-compatible
  with each other; you may bump them via Android Studio's suggestions afterwards.

## Project layout

```
app/src/main/java/com/raisa/ai/
  MainActivity.kt, RaisaApplication.kt, AppContainer.kt
  ui/            RaisaApp.kt (shell: backdrop + bottom bar + nav host)
  ui/theme/      Color, Type, Theme (dark: violet / purple / pink / blue)
  ui/components/ avatar, buttons, cards, input bar, chat bubble, settings rows ...
  ui/screens/    Splash, Home, Chat, Tools, History, Settings (+ view models)
  navigation/    Screen routes, bottom items, NavHost
  domain/        models + ChatRepository interface
  data/          InMemoryChatRepository
  ai/            AiResponder interface + LocalPlaceholderResponder (NOT Gemini)
  voice/         VoiceInputController interface + placeholder
  action/        tool catalog + ActionExecutor placeholder
  settings/      AppSettings + in-memory repository
```

## Logo

The supplied logo is stored at `res/drawable-nodpi/raisa_logo.png` (used on the splash and home
screens, and cropped to the face inside the avatar). Launcher icons are generated from it:
adaptive icon (`mipmap-anydpi-v26` + `drawable-nodpi/ic_launcher_foreground.png`) and legacy
PNGs in every `mipmap-*dpi` folder.

## Languages

Bengali is the default (`values/strings.xml`); English is in `values-en/strings.xml`.
The app follows the device language. On Android 13+ the language can also be chosen per app
in system settings (`res/xml/locales_config.xml`).

## Next

Step 02 (not started): Gemini integration behind the `AiResponder` interface.
